import org.junit.Test;
import org.junit.Ignore;
import static org.junit.Assert.assertEquals;

public class TestMessageUtil {

    String message = "Chris";
    MessageUtil messageUtil = new MessageUtil(message);

    @Test
    public voic testPrintMessage() {
        System.out.println("Inside testPrintMessage");
        assertEquals(message, messageUtil.printMessage());
    }

    @Test
    public void testSalutationMessage() {
        System.out.println("Inside testSalutationMessage");
        message = "Hi" + "Chris";
        assertEquals(message, messageUtil.salutationMessage());
    }

}
